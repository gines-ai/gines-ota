const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BSfVD3C7.js","assets/index-CVfkk9bi.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CVfkk9bi.js";const o=r("Share",{web:()=>t(()=>import("./web-BSfVD3C7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-q1YW4Bc5.js.map
