import{W as n}from"./index-CVfkk9bi.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-C7NWESTZ.js.map
