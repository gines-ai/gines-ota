const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C7NWESTZ.js","assets/index-CVfkk9bi.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CVfkk9bi.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-C7NWESTZ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-B7e6_Y4r.js.map
