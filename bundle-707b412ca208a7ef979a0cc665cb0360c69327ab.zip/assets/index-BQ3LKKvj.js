const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CldFVwJ1.js","assets/index-ewbGtdSJ.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ewbGtdSJ.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CldFVwJ1.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-BQ3LKKvj.js.map
