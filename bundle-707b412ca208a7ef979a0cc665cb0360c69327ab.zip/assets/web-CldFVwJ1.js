import{W as n}from"./index-ewbGtdSJ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-CldFVwJ1.js.map
