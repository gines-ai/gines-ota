const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C9Qud1L6.js","assets/index-ewbGtdSJ.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ewbGtdSJ.js";const o=r("Share",{web:()=>t(()=>import("./web-C9Qud1L6.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-CTQmshk9.js.map
