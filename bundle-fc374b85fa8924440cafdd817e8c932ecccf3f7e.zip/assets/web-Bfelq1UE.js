import{W as n}from"./index-DLWsYeLc.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-Bfelq1UE.js.map
