const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bfelq1UE.js","assets/index-DLWsYeLc.js","assets/index-QGW-NJ3N.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DLWsYeLc.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Bfelq1UE.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-DyMIfTb-.js.map
