const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DCX8U07B.js","assets/index-DLWsYeLc.js","assets/index-QGW-NJ3N.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DLWsYeLc.js";const o=r("Share",{web:()=>t(()=>import("./web-DCX8U07B.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-CT8oG0nb.js.map
