const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CetrQbY0.js","assets/index-Q6w2ecOX.js","assets/index-MH4UIqfy.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Q6w2ecOX.js";const o=r("Share",{web:()=>t(()=>import("./web-CetrQbY0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-DLUf9281.js.map
