import{W as o}from"./index-Q6w2ecOX.js";class p extends o{async login(){throw this.unavailable("login por loopback só no app nativo")}async probe(){throw this.unavailable("login por loopback só no app nativo")}}export{p as LoopbackAuthWeb};
//# sourceMappingURL=web-ByEwA2N3.js.map
