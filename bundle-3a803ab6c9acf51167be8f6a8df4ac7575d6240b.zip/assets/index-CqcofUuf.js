const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-2jcirToL.js","assets/index-Q6w2ecOX.js","assets/index-MH4UIqfy.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Q6w2ecOX.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-2jcirToL.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-CqcofUuf.js.map
