import{W as n}from"./index-Q6w2ecOX.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-2jcirToL.js.map
