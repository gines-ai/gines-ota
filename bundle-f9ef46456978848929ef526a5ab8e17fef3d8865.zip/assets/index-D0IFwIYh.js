const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BEDN8C1V.js","assets/index-DomccUD4.js","assets/index-Di9hTdJO.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DomccUD4.js";const o=r("Share",{web:()=>t(()=>import("./web-BEDN8C1V.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-D0IFwIYh.js.map
