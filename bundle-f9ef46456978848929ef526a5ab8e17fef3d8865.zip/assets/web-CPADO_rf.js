import{W as n}from"./index-DomccUD4.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-CPADO_rf.js.map
