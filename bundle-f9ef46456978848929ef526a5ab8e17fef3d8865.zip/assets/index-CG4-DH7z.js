const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CPADO_rf.js","assets/index-DomccUD4.js","assets/index-Di9hTdJO.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DomccUD4.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CPADO_rf.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-CG4-DH7z.js.map
