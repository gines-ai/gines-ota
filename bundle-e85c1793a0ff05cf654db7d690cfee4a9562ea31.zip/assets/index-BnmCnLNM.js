const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C7J3I4an.js","assets/index-DRbSCSzj.js","assets/index-BUCJXaRu.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DRbSCSzj.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-C7J3I4an.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-BnmCnLNM.js.map
