import{W as o}from"./index-DRbSCSzj.js";class p extends o{async login(){throw this.unavailable("login por loopback só no app nativo")}async probe(){throw this.unavailable("login por loopback só no app nativo")}}export{p as LoopbackAuthWeb};
//# sourceMappingURL=web-GNQtnB-8.js.map
