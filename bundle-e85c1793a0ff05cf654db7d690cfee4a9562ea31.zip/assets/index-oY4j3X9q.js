const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cg8tFTno.js","assets/index-DRbSCSzj.js","assets/index-BUCJXaRu.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DRbSCSzj.js";const o=r("Share",{web:()=>t(()=>import("./web-Cg8tFTno.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-oY4j3X9q.js.map
