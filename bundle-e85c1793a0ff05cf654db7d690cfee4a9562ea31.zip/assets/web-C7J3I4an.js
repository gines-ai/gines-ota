import{W as n}from"./index-DRbSCSzj.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-C7J3I4an.js.map
