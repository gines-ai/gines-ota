import{W as n}from"./index-DMiy1pF8.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-C5kbizUu.js.map
