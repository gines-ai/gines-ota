const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C5kbizUu.js","assets/index-DMiy1pF8.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DMiy1pF8.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-C5kbizUu.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-zZjLLLSd.js.map
