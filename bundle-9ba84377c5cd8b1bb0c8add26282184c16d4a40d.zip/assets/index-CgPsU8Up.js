const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DX4-S_ST.js","assets/index-DMiy1pF8.js","assets/index-BZymfNqH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DMiy1pF8.js";const o=r("Share",{web:()=>t(()=>import("./web-DX4-S_ST.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-CgPsU8Up.js.map
