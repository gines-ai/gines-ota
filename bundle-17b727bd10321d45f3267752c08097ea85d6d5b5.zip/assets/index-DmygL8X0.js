const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-tw7P_o2P.js","assets/index-C7MmNb9G.js","assets/index-DVOsMsUs.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C7MmNb9G.js";const o=r("Share",{web:()=>t(()=>import("./web-tw7P_o2P.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-DmygL8X0.js.map
