const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Du5ZzYsN.js","assets/index-C7MmNb9G.js","assets/index-DVOsMsUs.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C7MmNb9G.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Du5ZzYsN.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-CDyaa0ZD.js.map
