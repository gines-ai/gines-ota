import{W as n}from"./index-C7MmNb9G.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-Du5ZzYsN.js.map
