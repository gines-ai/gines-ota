const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CdNJutKH.js","assets/index-Dywh-RA5.js","assets/index-BCRLX7WC.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dywh-RA5.js";const o=r("Share",{web:()=>t(()=>import("./web-CdNJutKH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-BuLYsqzf.js.map
