import{W as n}from"./index-Dywh-RA5.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-BLCOBYjZ.js.map
