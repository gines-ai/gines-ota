const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BLCOBYjZ.js","assets/index-Dywh-RA5.js","assets/index-BCRLX7WC.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dywh-RA5.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BLCOBYjZ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-DN21nqIE.js.map
