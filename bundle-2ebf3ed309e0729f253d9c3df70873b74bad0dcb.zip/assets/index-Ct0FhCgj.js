const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DUWQSpdZ.js","assets/index-Cdl45T6H.js","assets/index-DPXcSZcq.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cdl45T6H.js";const o=r("Share",{web:()=>t(()=>import("./web-DUWQSpdZ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-Ct0FhCgj.js.map
