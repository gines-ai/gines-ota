const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CE4qoYil.js","assets/index-Cdl45T6H.js","assets/index-DPXcSZcq.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cdl45T6H.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CE4qoYil.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
//# sourceMappingURL=index-BV0SyKot.js.map
