import{W as n}from"./index-Cdl45T6H.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-CE4qoYil.js.map
