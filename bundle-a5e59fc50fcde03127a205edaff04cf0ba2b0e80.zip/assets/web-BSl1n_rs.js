import{W as o}from"./index-BECM3Lwe.js";class p extends o{async login(){throw this.unavailable("login por loopback só no app nativo")}async probe(){throw this.unavailable("login por loopback só no app nativo")}}export{p as LoopbackAuthWeb};
//# sourceMappingURL=web-BSl1n_rs.js.map
