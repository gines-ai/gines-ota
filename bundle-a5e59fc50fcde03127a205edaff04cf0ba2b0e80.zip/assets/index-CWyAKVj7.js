const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DmXDSeGq.js","assets/index-BECM3Lwe.js","assets/index-ag6W6-cX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BECM3Lwe.js";const o=r("Share",{web:()=>t(()=>import("./web-DmXDSeGq.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
//# sourceMappingURL=index-CWyAKVj7.js.map
