import{W as n}from"./index-BECM3Lwe.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-BTrvAfiz.js.map
